# Facial_emotion_base_music_rds
This project suggest songs base on your facial expression  such as- happy,sad,natural,surprised,rock etc  or you can enter singer and language also for the songs you want to listen 
